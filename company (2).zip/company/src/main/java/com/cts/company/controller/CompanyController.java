package com.cts.company.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.company.entity.Company;
import com.cts.company.entity.IpoDetail;
import com.cts.company.service.CompanyServiceImpl;

@RestController
@RequestMapping("/company")
public class CompanyController {
	
	private static String RESULT = "results";
	private static String MESSAGE = "message";
	private static String STATUS = "status";
	private static String STATUS_OK = "200";
	private static String STATUS_BAD_REQUEST = "400";
	
	@Autowired
	CompanyServiceImpl companyServiceImpl;
	
	@GetMapping()
	public ResponseEntity<List<Company>> listCompany(){
//	public ResponseEntity<HashMap<String, Object>> listCompany(){
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		List<Company> company = new ArrayList<Company>();
		company = companyServiceImpl.companyList();
		if(company.size()==0) {
			hashMap.put(STATUS, STATUS_BAD_REQUEST);
			hashMap.put(MESSAGE, "No records Found");
			return new ResponseEntity<List<Company>>(company, HttpStatus.FORBIDDEN);
		}else {
			hashMap.put(STATUS, STATUS_OK);
			hashMap.put(MESSAGE, "Records Found");
			return new ResponseEntity<List<Company>>(company, HttpStatus.OK);
		}
	}
	
	@PostMapping()
	public ResponseEntity<HashMap<String, Object>> companyAdd(@RequestBody Company company){
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		String check = companyServiceImpl.addCompany(company);
		if(check.equals("added")) {
			hashMap.put(STATUS, STATUS_OK);
			hashMap.put(MESSAGE, "added stock exchange");
			hashMap.put(RESULT, "");
			return new ResponseEntity<HashMap<String,Object>>(hashMap, HttpStatus.OK);
		}else {
			hashMap.put(STATUS, STATUS_BAD_REQUEST);
			hashMap.put(MESSAGE, "error adding stock exchange");
			hashMap.put(RESULT, "");
			return new ResponseEntity<HashMap<String,Object>>(hashMap, HttpStatus.FORBIDDEN);
		}
	}
	
	@PostMapping("/update")
	public ResponseEntity<HashMap<String, Object>> companyUpdate(@RequestBody Company company){
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		String check = companyServiceImpl.updateCompany(company);
		if(check.equals("updated")) {
			hashMap.put(STATUS, STATUS_OK);
			hashMap.put(MESSAGE, "updated stock exchange");
			hashMap.put(RESULT, "");
			return new ResponseEntity<HashMap<String,Object>>(hashMap, HttpStatus.OK);
		}else {
			hashMap.put(STATUS, STATUS_BAD_REQUEST);
			hashMap.put(MESSAGE, "error updating stock exchange");
			hashMap.put(RESULT, "");
			return new ResponseEntity<HashMap<String,Object>>(hashMap, HttpStatus.FORBIDDEN);
		}
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<HashMap<String, Object>> activation(@PathVariable int id){
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		String check = companyServiceImpl.activationStatus(id);
		if(check.equals("activated") || check.equals("deactivated")) {
			hashMap.put(STATUS, STATUS_OK);
			hashMap.put(MESSAGE, "Activation status updated");
			hashMap.put(RESULT, "");
			return new ResponseEntity<HashMap<String,Object>>(hashMap, HttpStatus.OK);
		}else {
			hashMap.put(STATUS, STATUS_BAD_REQUEST);
			hashMap.put(MESSAGE, "error in activation status");
			hashMap.put(RESULT, "");
			return new ResponseEntity<HashMap<String,Object>>(hashMap, HttpStatus.FORBIDDEN);
		}
	}
	
	@PostMapping("/ipoupdate")
	public ResponseEntity<HashMap<String, Object>> ipoUpdate(@RequestBody IpoDetail ipoDetail){
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		String check = companyServiceImpl.updateIpo(ipoDetail);
		if(check.equals("updated")) {
			hashMap.put(STATUS, STATUS_OK);
			hashMap.put(MESSAGE, "updated ipo details");
			hashMap.put(RESULT, "");
			return new ResponseEntity<HashMap<String,Object>>(hashMap, HttpStatus.OK);
		}else {
			hashMap.put(STATUS, STATUS_BAD_REQUEST);
			hashMap.put(MESSAGE, "error updating ipo details");
			hashMap.put(RESULT, "");
			return new ResponseEntity<HashMap<String,Object>>(hashMap, HttpStatus.FORBIDDEN);
		}
	}
}
