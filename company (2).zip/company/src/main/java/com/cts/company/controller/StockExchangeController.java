package com.cts.company.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.company.entity.StockExchange;
import com.cts.company.service.StockExchangeServiceImpl;

@RestController
@RequestMapping("/stock")
public class StockExchangeController {
	
	private static String RESULT = "results";
	private static String MESSAGE = "message";
	private static String STATUS = "status";
	private static String STATUS_OK = "200";
	private static String STATUS_BAD_REQUEST = "400";
	
	@Autowired
	StockExchangeServiceImpl serviceImpl;
	
	@GetMapping()
	public ResponseEntity<List<StockExchange>> listStock(){
//	public ResponseEntity<HashMap<String, Object>> listStock(){
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		List<StockExchange> stockExchange = new ArrayList<StockExchange>();
		stockExchange = serviceImpl.stockList();
		if(stockExchange.size()==0) {
			hashMap.put(STATUS, STATUS_BAD_REQUEST);
			hashMap.put(MESSAGE, "No records Found");
			return new ResponseEntity<List<StockExchange>>(stockExchange, HttpStatus.FORBIDDEN);
		}else {
			hashMap.put(STATUS, STATUS_OK);
			hashMap.put(MESSAGE, "Records Found");
			return new ResponseEntity<List<StockExchange>>(stockExchange, HttpStatus.OK);
		}
		
	}
	
	@PostMapping()
	public ResponseEntity<HashMap<String, Object>> stockAdd(@RequestBody StockExchange stockExchange){
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		String check = serviceImpl.addStock(stockExchange);
		if(check.equals("added")) {
			hashMap.put(STATUS, STATUS_OK);
			hashMap.put(MESSAGE, "added stock exchange");
			hashMap.put(RESULT, "");
		}else if(check.equals("error")) {
			hashMap.put(STATUS, STATUS_BAD_REQUEST);
			hashMap.put(MESSAGE, "error adding stock exchange");
			hashMap.put(RESULT, "");
		}
		return new ResponseEntity<HashMap<String,Object>>(hashMap, HttpStatus.OK);
	}

}
